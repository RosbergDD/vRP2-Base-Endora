-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2020 at 08:55 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vrp`
--

-- --------------------------------------------------------

--
-- Table structure for table `vrp_characters`
--

CREATE TABLE `vrp_characters` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vrp_characters`
--

-- --------------------------------------------------------

--
-- Table structure for table `vrp_character_business`
--

CREATE TABLE `vrp_character_business` (
  `character_id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `capital` int(11) DEFAULT NULL,
  `laundered` int(11) DEFAULT NULL,
  `reset_timestamp` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `vrp_character_data`
--

CREATE TABLE `vrp_character_data` (
  `character_id` int(11) NOT NULL,
  `dkey` varchar(100) NOT NULL,
  `dvalue` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vrp_character_data`
--
-- --------------------------------------------------------

--
-- Table structure for table `vrp_character_homes`
--

CREATE TABLE `vrp_character_homes` (
  `character_id` int(11) NOT NULL,
  `home` varchar(100) DEFAULT NULL,
  `number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `vrp_character_identities`
--

CREATE TABLE `vrp_character_identities` (
  `character_id` int(11) NOT NULL,
  `registration` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vrp_character_identities`
--
-- --------------------------------------------------------

--
-- Table structure for table `vrp_global_data`
--

CREATE TABLE `vrp_global_data` (
  `dkey` varchar(100) NOT NULL,
  `dvalue` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vrp_global_data`
--
-- --------------------------------------------------------

--
-- Table structure for table `vrp_server_data`
--

CREATE TABLE `vrp_server_data` (
  `id` varchar(100) NOT NULL,
  `dkey` varchar(100) NOT NULL,
  `dvalue` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vrp_server_data`
--
-- --------------------------------------------------------

--
-- Table structure for table `vrp_users`
--

CREATE TABLE `vrp_users` (
  `id` int(11) NOT NULL,
  `whitelisted` tinyint(1) DEFAULT NULL,
  `banned` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vrp_users`
--

-- --------------------------------------------------------

--
-- Table structure for table `vrp_user_data`
--

CREATE TABLE `vrp_user_data` (
  `user_id` int(11) NOT NULL,
  `dkey` varchar(100) NOT NULL,
  `dvalue` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vrp_user_data`
--
-- --------------------------------------------------------

--
-- Table structure for table `vrp_user_ids`
--

CREATE TABLE `vrp_user_ids` (
  `identifier` varchar(100) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vrp_user_ids`
--
--
-- Indexes for dumped tables
--

--
-- Indexes for table `vrp_characters`
--
ALTER TABLE `vrp_characters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_characters_users` (`user_id`);

--
-- Indexes for table `vrp_character_business`
--
ALTER TABLE `vrp_character_business`
  ADD PRIMARY KEY (`character_id`);

--
-- Indexes for table `vrp_character_data`
--
ALTER TABLE `vrp_character_data`
  ADD PRIMARY KEY (`character_id`,`dkey`);

--
-- Indexes for table `vrp_character_homes`
--
ALTER TABLE `vrp_character_homes`
  ADD PRIMARY KEY (`character_id`),
  ADD UNIQUE KEY `home` (`home`,`number`);

--
-- Indexes for table `vrp_character_identities`
--
ALTER TABLE `vrp_character_identities`
  ADD PRIMARY KEY (`character_id`),
  ADD KEY `registration` (`registration`),
  ADD KEY `phone` (`phone`);

--
-- Indexes for table `vrp_global_data`
--
ALTER TABLE `vrp_global_data`
  ADD PRIMARY KEY (`dkey`);

--
-- Indexes for table `vrp_server_data`
--
ALTER TABLE `vrp_server_data`
  ADD PRIMARY KEY (`id`,`dkey`);

--
-- Indexes for table `vrp_users`
--
ALTER TABLE `vrp_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vrp_user_data`
--
ALTER TABLE `vrp_user_data`
  ADD PRIMARY KEY (`user_id`,`dkey`);

--
-- Indexes for table `vrp_user_ids`
--
ALTER TABLE `vrp_user_ids`
  ADD PRIMARY KEY (`identifier`),
  ADD KEY `fk_user_ids_users` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vrp_characters`
--
ALTER TABLE `vrp_characters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vrp_users`
--
ALTER TABLE `vrp_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `vrp_characters`
--
ALTER TABLE `vrp_characters`
  ADD CONSTRAINT `fk_characters_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vrp_character_business`
--
ALTER TABLE `vrp_character_business`
  ADD CONSTRAINT `fk_character_business_characters` FOREIGN KEY (`character_id`) REFERENCES `vrp_characters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vrp_character_data`
--
ALTER TABLE `vrp_character_data`
  ADD CONSTRAINT `fk_character_data_characters` FOREIGN KEY (`character_id`) REFERENCES `vrp_characters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vrp_character_homes`
--
ALTER TABLE `vrp_character_homes`
  ADD CONSTRAINT `fk_character_homes_characters` FOREIGN KEY (`character_id`) REFERENCES `vrp_characters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vrp_character_identities`
--
ALTER TABLE `vrp_character_identities`
  ADD CONSTRAINT `fk_character_identities_characters` FOREIGN KEY (`character_id`) REFERENCES `vrp_characters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vrp_user_data`
--
ALTER TABLE `vrp_user_data`
  ADD CONSTRAINT `fk_user_data_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vrp_user_ids`
--
ALTER TABLE `vrp_user_ids`
  ADD CONSTRAINT `fk_user_ids_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
