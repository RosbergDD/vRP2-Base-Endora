dependency 'obituary'

description 'death messages using the obituary resource'

client_script 'deathmessages.lua'
