dependency 'yarn'
--server_only 'yes'
server_script 'webpack_builder.js'