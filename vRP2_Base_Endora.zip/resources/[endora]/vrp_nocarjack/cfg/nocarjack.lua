

cfg = {}

cfg.chance = 70 -- chance of being unlocked in percentage

cfg.blacklist = { -- vehicles that will always be locked when spawned naturally
  "T20",
  "RHINO"
}

return cfg
