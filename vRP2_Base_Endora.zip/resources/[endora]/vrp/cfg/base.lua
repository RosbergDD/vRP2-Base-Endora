
local cfg = {}

-- mysql credentials
cfg.db = {
  driver = "ghmattimysql",
  host = "127.0.0.1",
  database = "vRP",
  user = "root",
  password = ""
}

cfg.server_id = "main" 

cfg.save_interval = 60 -- secunde
cfg.whitelist = false -- activeaza/dezactiveaza whitelist


cfg.load_duration = 30 
cfg.load_delay = 60 
cfg.global_delay = 0 

cfg.ping_check_interval = 0 
cfg.ping_timeout_misses = 10 

cfg.max_characters = 5 -- maximul de caractere/utilizator
cfg.character_select_delay = 60 -- minimul de timp pentru a alege caracterul dorit

cfg.ignore_ip_identifier = true

cfg.lang = "ro"

cfg.log_level = 0

return cfg
